# Phone Mirror — Local WiFi Screen Mirror + Remote Tap Control

No cloud server, no internet needed — everything runs on the phone itself over
your local WiFi network, like ApowerMirror's local mode.

## How it works
1. Phone runs a tiny embedded web server (`MjpegServer.kt`) on port 8080.
2. Phone screen is captured with Android's `MediaProjection` API and streamed
   as an MJPEG video feed at `http://<phone-ip>:8080/stream`.
3. Open `http://<phone-ip>:8080` in any browser on a laptop/PC on the **same
   WiFi network** — you'll see the phone's live screen.
4. Clicking on the mirrored image sends the tap coordinates back to the phone
   over a WebSocket, and Android's `AccessibilityService` performs the actual
   tap — e.g. clicking the YouTube icon on the mirrored screen opens YouTube
   on the real phone.

## Setup
1. Open this folder in **Android Studio**.
2. Let Gradle sync (downloads the NanoHTTPD + ZXing dependencies).
3. Run the app on a real Android phone (min SDK 26 / Android 8+).
   MediaProjection/screen capture does not work reliably on the emulator.
4. On first launch:
   - Tap **"Enable Tap Control (Accessibility)"** and turn on "Phone Mirror"
     in Settings → Accessibility. Android *requires* this to be done manually
     by the user — no app can enable it silently, as an anti-malware
     protection.
   - Tap **"Start Mirroring"** and accept the screen-capture permission
     prompt (Android also requires this every session, by design).
5. The app shows the phone's local IP and a QR code. On your laptop (same
   WiFi/hotspot), open that address in a browser.

## Known limitations of this starter version
- Both devices must be on the same WiFi network (or phone hotspot).
- MJPEG over HTTP is simple and reliable but not as bandwidth-efficient as a
  proper WebRTC stream — fine for local network use; noticeable lag if you
  push it over the internet later.
- Only single-tap gestures are wired up; swipe/scroll/long-press/keyboard
  input would need small additions to `TapAccessibilityService.kt` and
  `viewer.html` (structure is already there to extend).
- No pairing/auth — anyone on the same WiFi who has the IP can view/control
  it while mirroring is active. Fine for personal/home use; add a
  password/token check in `MjpegServer.kt` before using on shared networks.

## Extending it
- **Swipe/scroll**: add a `dispatchSwipe(x1,y1,x2,y2)` similar to `dispatchTap`
  in `TapAccessibilityService.kt`, and send drag events from `viewer.html`.
- **Text input**: accessibility services can also set text on focused fields.
- **Better performance**: swap the MJPEG pipeline for WebRTC using an Android
  WebRTC library if you need lower latency / lower bandwidth.
