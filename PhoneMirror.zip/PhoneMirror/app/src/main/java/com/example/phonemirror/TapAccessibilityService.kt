package com.example.phonemirror

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * User must manually enable this once in Settings > Accessibility (Android does not allow
 * apps to turn this on for themselves - it's a deliberate anti-malware protection).
 *
 * Once enabled, it can turn (x, y) coordinates sent from the browser viewer into a real
 * tap on the phone's screen - e.g. tapping the YouTube icon shown in the mirrored view.
 */
class TapAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instance: TapAccessibilityService? = null

        fun performTapAt(x: Float, y: Float) {
            instance?.dispatchTap(x, y)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    private fun dispatchTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
